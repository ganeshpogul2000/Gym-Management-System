<img src="images/package.png" style="width:400px; height:250px;" alt="">
         
            <div class="row justify-content-center">
              <div class="col-md-7">
              <span style="font-size:20px;">Rs.10000&nbsp&nbsp&nbsp&nbsp&nbspRs.20000&nbsp&nbsp&nbsp&nbsp&nbspRs.30000</span>
                <form method="post"  action="">
                  <div class="form-group row">
                    <div class="col-md-6 mb-3 mb-lg-0">
                   
                      <input type="text" class="form-control" name="ch"  style="margin-left:100px; margin-top:20px;" placeholder="Enter your choice...">
                    </div>
                  </div>  
                    <div class="form-group row">
                      <div class="col-md-6">
          
                        <input type="submit" name="btn2"  class="btn btn-primary py-3 px-5 btn-block" style="margin-left:100px; margin-top:20px;" value="Submit">
                       
                      </div>
                    </div>

                </form>

              </div>
            </div>
