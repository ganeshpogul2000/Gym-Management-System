<?php include("header.php");


echo "Welcome To Admin Panel";


include("footer.php");
?>

